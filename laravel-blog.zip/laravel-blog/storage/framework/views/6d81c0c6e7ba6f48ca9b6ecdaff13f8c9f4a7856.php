<?php /* E:\xampps\htdocs\laravel-blog\resources\views/frontend/post.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo e($post->title); ?> - <small>by <?php echo e($post->user->name); ?></small>

                        <span class="pull-right">
                            <?php echo e($post->created_at->toDayDateTimeString()); ?>

                        </span>
                    </div>

                    <div class="panel-body">
                        <p><?php echo e($post->body); ?></p>
                    </div>
                </div>

                <?php echo $__env->renderWhen(Auth::user(), 'frontend._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

                <?php echo $__env->make('frontend._comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

        </dev>
    </dev>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>